exports.handler = async function(event) {
  const headers = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,OPTIONS','Content-Type':'application/json'};
  if (event.httpMethod === 'OPTIONS') return {statusCode:200,headers,body:''};
  if (event.httpMethod !== 'POST') return {statusCode:405,headers,body:JSON.stringify({error:'Method not allowed'})};
  try {
    const apiKey = process.env.ANTHROPIC_API_KEY || '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';
    const body = JSON.parse(event.body);
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method:'POST',
      headers:{'Content-Type':'application/json','x-api-key':apiKey,'anthropic-version':'2023-06-01'},
      body:JSON.stringify({model:body.model||'claude-sonnet-4-20250514',max_tokens:body.max_tokens||1400,messages:body.messages})
    });
    const data = await response.json();
    return {statusCode:response.status,headers,body:JSON.stringify(data)};
  } catch(err) {
    return {statusCode:500,headers,body:JSON.stringify({error:{message:err.message}})};
  }
};
